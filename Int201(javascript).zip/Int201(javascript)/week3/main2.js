// //a, b, c, e are global scope
// let a = 1
// const b = 2
// var c = 3
// //d, e are block scope
// {
//   //d and e are local variables in block
//   let d = 4
//   const e = 5
//   var f = 6
//   console.log('block area')
//   console.log(a)
//   console.log(b)
//   console.log(c)
// }
// //h, i, j are function scope
// function doIt() {
//   //h, i, j are local variable in function
//   let h = 7
//   const i = 8
//   var j = 9

//   console.log('function area')
//   console.log(a)
//   console.log(b)
//   console.log(c)

//   console.log(f)
//   // block scope variables do not allow outside block
//   //   console.log(d)
//   //   console.log(e)
// }
// doIt()
// console.log('global area')
// console.log(a)
// console.log(b)
// console.log(c)

// function scope variables do not allow outside function
// console.log(h)
// console.log(i)
// console.log(j)

// console.log(f)
// block scope variables do not allow outside block
// console.log(d)
// console.log(e)

//x is global scope
// let x = 1
// {
//     //x is a block scope
//     let x = 2
//     console.log(x);
// }
// function doIt(y) {
//     //y is function scope
//     console.log(y);
// }
// console.log(x);
// doIt(100)
// console.log(x);


// let msg = 'hello'
// console.log(msg.charAt(0));
// let msgs = [...msg]
// console.log(msgs);

//optional chaining ?.
// let a=[]
// //with array
// console.log(a?.[0]);

// //with object
// let b = {id: 0, fullname: 'shisanucha'}
// //1.
// console.log(b?.id);
// console.log(b['id']);
// Return the number (count) of vowels (a, e, i, o, u) in the given string. The input string will only consist of lower case letters and/or spaces.
// const getCount = str => {
//   // Your solution
  
// };

// console.log(getCount('my pyx')); // 0
// console.log(getCount('pear tree')); // 4
// console.log(getCount('abracadabra')); // 5
// console.log(getCount('o a kak ushakov lil vo kashu kakao')); // 13