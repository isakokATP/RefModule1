// let num = 1
// console.log(typeof num);
// num = true
// console.log(typeof num);

// if (typeof num === 'Boolean')
// console.log('num is a boolean type')

// let a = 1n
// console.log(typeof a);

// let b = 3.2
// console.log(typeof b);

// let c = `A-${b/ 2 + 1}`
// console.log(c)
// console.log(typeof c)

// // implicit type conversion (String to boolean)
// if ('1') console.log('1 is a boolean true')
// else console.log('value is not zero');

// if ('0') console.log('value is zero')
// else console.log('value is not zero')

// if ('2') console.log('value is two')
// else console.log('value is not two')

// let msg = 'a'
// if (msg) console.log('an empty String')
// else console.log('is not empty String');

// // mutable
// // sample array data type[]
// const nums = [1, 3, 5, 7, 9, 11]
// nums[nums.length - 2] = 12
// // nums.push(9)
// // nums[0] = 11 
// console.log(nums);
// console.log(typeof nums)

// // sample object data type: collection of properties {}
// const obj = {id: 1, price: 100}
// obj.id = 11
// console.log(obj);
// console.log(typeof obj);

function doSomething(activity) {
// === check data type and value | == check value
    if (activity === null || activity === undefined) {
        return 'no activity'
    } else return `${activity} is done`
}
console.log(typeof doSomething);
console.log(doSomething('play game'));

let act1
let act2 = null
let act3 = 'js learning'
console.log(doSomething(act1)); //no act
console.log(doSomething(act2)); //no act
console.log(doSomething(act3)); // js learing
console.log(doSomething()); // no act

// const pee = 'Just friend'
// pee = 'boy friend'
// console.log(pee);

let aa,
    bb = 0,
    cc = null

console.log(aa); //undefined
console.log(bb);

let num = 0;
console.log(num);
num = 2;
console.log(num);