const myCookies = document.cookie
console.log(myCookies);

document.cookie = 'course=INT201;expires=max-age=300'
console.log(myCookies);

document.cookie = `credit=3;expires=${new Date(Date.now() + 1000 * 60 * 60 * 24)}`
//new Date(year, monthIndex, Day)
document.cookie = `lecturer=shisanucha;expires=${new Date(2023, 11, 25)}`
console.log(myCookies);