//synchronous programimng
//interpreter translater
// function greeting(someone) {
//     return 'hello, ' + someone
// }
// let $myName = 'shisanucha chengsamo';
// $myName = 10 //weakly and dynamic data stype
// console.log('staring...')
// //asynchronous programmimg
// setTimeout(()=>{
//     console.log('more complex task finish');
// }, 10000)
// console.log(greeting($myName));
// setTimeout(()=>{
//     console.log("complex task finish...")
// }, 2000 ) 
// console.log('Good bye...');

// let msg="I'm suck student"
// console.log(msg);

let a = null
console.log(a);
let total
console.log(total);
if (total === undefined) console.log('varible does not have intitial value');
if (a === null) console.log('variable has null value');

//backtick ``
if('2' == 2)console.log(`'2 ==2' :${'2' == 2}`);
if('2' === 2)console.log(`'2 ===2' :${'2' === 2}`);

//Object sample
const obj = { id: 1001, name: 'pen', price: 100 }
const obj2 = {id: 2001}

// obj = obj2 //obj cannot change reference value
obj.id = 999//but obj can update its properties
console.log(obj);
