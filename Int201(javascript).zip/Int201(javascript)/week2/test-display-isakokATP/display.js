function display(message) {
  //code here
  if (message == null | message == undefined) {
      return 'no message'
  }
  else {
    return `your message is ${message}`}
  }

module.exports = display
