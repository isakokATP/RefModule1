const body = document.body
const bodyChildNodes = body.childNodes // datatype is not array method ใช้ได้เฉพาะ for each จะให้ค่าเป็นnode typeทั้งหมด
const bodyChildren = body.children //datatype is not array method จะให้ค่าเป็น element type

console.log(body)
console.log(bodyChildNodes)
console.log(bodyChildren)
bodyChildNodes.forEach((bcn) => {
  console.log(bcn)
})
Array.from(bodyChildren).forEach((bc) => {
  console.log(bc)
})


console.log(body.firstChild);
console.log(body.firstElementChild);
console.log(body.lastChild);
console.log(body.lastElementChild);

console.log(body.firstChild === body.firstElementChild);
console.log(body.lastChild === body.lastElementChild);

console.log(document.documentElement === document.firstElementChild);


const course201 = document.getElementById('int201') // case sensitive INT and int different
console.log(course201);

const course101Ele = document.querySelector('#int101')
console.log(course101Ele);

const bscitCourses = document.querySelector('#int101, #bscit-courses')
console.log(bscitCourses);

//select query a collection of element
//find with css selector
const proEle = document.querySelectorAll('#int201, programming')
console.log(proEle);
const liEle1 = document.querySelectorAll('li')
console.log(liEle1); // nodelist

//find with tagName
const liEle2 = document.getElementsByTagName('li')
console.log(liEle2); // HTML Collection

const firstDiv = document.body.firstElementChild
console.log(firstDiv);
const firstDivAttributes = firstDiv.attributes
console.log(firstDivAttributes); //length = 2 and class attributes

Array.from(firstDivAttributes).forEach((attr) => {
    console.log(attr.name);
    console.log(attr.value);
})

console.log(firstDiv.getAttribute('id')); //return value of specified attribute 'id'
console.log(firstDiv.getAttribute('class'));

const firstAttributes = firstDivAttributes[0]
console.log(firstAttributes.ownerDocument);
console.log(firstAttributes.ownerElement);


firstDiv.setAttribute('owner', 'Umaporn')

//How to Add new element and Parent
const newPEle = document.createElement('p') //<p></p>
newPEle.textContent = 'Client Web Programming II' //<p>Client Web Programming</p>
newPEle.setAttribute('id','int203') //<p id="int203">Client Web Programming</p>
newPEle.setAttribute('class', 'courses') //<p id="int203" class = "courses">Client Web Programming</p>
const divCoursesParent = document.getElementById('bscit-courses')
// divCoursesParent.appendChild(newPEle)

const refNode = divCoursesParent.lastElementChild
// divCoursesParent.insertBefore(newPEle, refNode)
divCoursesParent.replaceChild(newPEle, refNode) //replace 201

divCoursesParent.removeChild(newPEle)

window.alert('Do you want to be friend?')
const username = window.prompt('Please enter your status', 'Exam: friend!!!') // cancel return null, if ok return name value
console.log(username);
const userAction = window.confirm(`Good Luck in ur relationship, ${username}`)
console.log(userAction);
