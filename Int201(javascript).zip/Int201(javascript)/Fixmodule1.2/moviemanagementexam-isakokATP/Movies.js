//your student id, firstname, and lastname here
//65130500016 shisanucha chengsamo
class Movies {
  //your code here...
  
}

module.exports = Movies
