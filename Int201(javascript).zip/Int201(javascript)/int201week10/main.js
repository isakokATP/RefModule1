function ops(n1= 0, n2= false, n3 = "unknown") {
    console.log(n1, n2, n3);
}

ops(555, true)

function sum(n1,n2,n3) {
    return n1 + n2 + n3;
}
const nums = [10,20,30]
console.log(sum(nums));
console.log(sum(...nums));