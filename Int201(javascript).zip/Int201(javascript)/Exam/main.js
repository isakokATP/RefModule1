// const x =5;

// for(let i = 1; i <= x; i++) {
//     console.log(i);
// }

let sum = 0;
const n = 100;

for (let i = 1; i <= n; i++) {
    sum+= i; 
}
console.log('sum:', sum);