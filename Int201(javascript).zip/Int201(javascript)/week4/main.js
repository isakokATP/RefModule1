// let n = m ?? 0 
// console.log(n);

// let y = []
// console.log(y)
// let z = {}
// console.log(z);

// let x = 1.2
// console.log(typeof x);

// let a
// a=a ?? y
// console.log(a);

// console.log(Math.PI)
// console.log(Math.pow)

// const rand = Math.random() * (100 - 25) + 25
// console.log(rand);

// function RandomNumber() {
//     return Math.floor(Math.random() * (max - min + 1)) + min
// }

// const rand2 = RandomNumber(12, 20);

//array data type 
let x = [1,3, true, 'unknown']
//object
let m ={id: 1, title: 'pen'}

let scores = 70
let grade = 'f'
if(scores<0 || scores>100) grade = 'invalid'
else if(scores > 70) grade = 'Very good'
else if(scores<40) grade = 'good'
