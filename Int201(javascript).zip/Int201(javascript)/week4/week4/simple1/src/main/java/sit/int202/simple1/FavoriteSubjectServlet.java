package sit.int202.simple1;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

@WebServlet(name = "FavoriteSubjectServlet", value = "/favoriteSubject")   //favoriteSubject มาจาก action ของเอกสาร HTML เพื่อนำเอกสารมาทำงานบน servlet แล้วให้ client
public class FavoriteSubjectServlet extends HttpServlet {
    private String message;  // สร้างตัวแปร

    public void init() {
        message = "Stop Your Thought!";
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //ไม่ได้สร้าง object ใดๆเลย จะเป็นค่าว่าง หน้าWeb= ว่างเปล่า
        doProcess(request, response);     //เรียกใช้ method doProcess

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response);    //เรียกใช้ method doProcess
    }

    private void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       //Method doProcess นี้สร้างไว้เพื่อเรียกใช้ทั้ง Get, Post โดยเขียนโค้ดไว้แค่ที่เดียว *แต่ถ้าโค้ดที่ใช้แสดงใน Get, Post ก็ไปเขียนไว้ในแต่ละ method แยกกัน
        //ทำงานกับเอกสาร HTML ตรง method="get" เปลี่ยนเป็น Post เพื่อเรียกใช้ Post ได้
        String name = request.getParameter("name");
        String id = request.getParameter("id");
        String[] favoriteSubject = request.getParameterValues("favorite_subject");

        //response
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Your favorite Subject:: </h1><br>");
        out.println("<h2>" + message + "</h2>");      //ทำเล่นๆๆ
        out.println("Student Id : " + id + "<br>");
        out.println("Student Name : " + name + "<br>");
        out.println("Favorite Subject : <br>");
        for (String subject : favoriteSubject){
            out.println("&nbsp;&nbsp; -" + subject + "<br>");
        }

        //ใช้ request.getParameterMap();
        Map<String, String[]> param = request.getParameterMap();
        out.println("<hr>");
        out.println("Request Parameter from Map:: <br>");
        out.println("Student Id = " + param.get("id")[0] + "<br>");
        out.println("Student Name = " + param.get("name")[0] + "<br>");
        out.println("Favorite Subject : <br>");
        for (String subject : param.get("favoriteSubject")){
            out.println("&nbsp;&nbsp; -" + subject + "<br>");
        }
        out.println("</body></html>");
    }
}
