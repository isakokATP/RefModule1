// // let str1 = 'ant'
// // let str2 = 'Ant'
// // let str3 = 'ANT'
// // let str4 = 'ant'

// // console.log(str1 === str2);
// // console.log(str1 !== str3);
// // console.log(str2 === str3);
// // console.log(str1 === str4);
// // console.log(str1 < str2);

// let x = [1,3, true, 'undefined']
// let y = [1,3, true, 'undefined']
// let z = x // give memory address from x to z
// console.log(x === y); // false cuz memory address of x === memory  address of y
// console.log(x === z); // true cuz memory address of x === memory  address of z
// console.log('-----------------------------------------');

// //Object data type
// let m = {id: 1, title: 'pen'}
// let n = {id: 1, title: 'pen'}
// let o = m // give memory from m to o
// console.log(m === n);
// console.log(o === m);
// o.id = 888
// console.log(o);
// console.log(m);

// //primary type
// let a = 5
// let b = 5
// let c = a // give data 5 from a to c
// console.log(a === b);
// console.log(c === a);


