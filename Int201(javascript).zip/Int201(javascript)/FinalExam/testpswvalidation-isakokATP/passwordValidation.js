// Write your student id, firstname, and lastname in a single line comment here
//student ID:65130500016 Name: shisanucha chengsamo

const digit = [0,1,2,3,4,5,6,7,8,9];
const special = ['@', '#', '$',' %', '^', '&', '\*', '!'];
function isPasswordValid(password) {
  //write your code here...

  if(password === null || password === undefined) {
    return false;
  }
  if(password.length < 8) {
    return false;
  }


  let pass = password.split("");
  let hasUpper = true;
  let hasLower = true;
  let hasDigit = false;
  let hasSpecial = false;

  for (let i = 0; i < password.length; i++) {
      if(pass[i] !== pass[i].toUpperCase()) {
        hasUpper = false;
      }
      if(pass[i] !== pass[i].toLowerCase()) {
        hasLower = false;
      }
      if(digit.includes(Number(pass[i]))){
        hasDigit = true;
      }
      if(special.includes(pass[i])) {
        hasSpecial = true;
      }
  } return  hasDigit && hasSpecial && hasUpper && hasLower;
  }


console.log(isPasswordValid('123456789asd'));

module.exports = isPasswordValid
