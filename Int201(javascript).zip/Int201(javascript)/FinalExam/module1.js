//ให้เขียน function ให้รับค่าที่เป็นตัวเลขเข้ามา 1 ค่า จากนั้นนับจำนวนค่า null หรือ undefined ข้างใน array หากจำนวน ของค่า null หรือ undefined มากกว่า 
//ค่า parameter ที่รับเข้ามาให้ return true หากน้อยกว่าให้ return false

const a = [1, 2, 'a','b' ,'c' ,true ,null , null, null, undefined, undefined]

function doSomething(b) {
    let c = 0;
    for (let i = 0; i < a.length; i++) {
    if(a[i] === null || a[i] === undefined) {
        c = c + 1;
    }
}
    if(c < b || c !== b) {
    return true;
    } return false;
}

console.log(doSomething('a'));

