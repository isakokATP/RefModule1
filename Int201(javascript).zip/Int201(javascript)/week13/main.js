// const outerdiv = document.getElementById('outer-div')
// const innerdiv = document.getElementById('inner-div')
// const submitButton = document.querySelector('button')

// outerdiv.addEventListener('click', (e) => {
//     console.log('outer div clicked')
//     console.log(e.type) //click
//     console.log(e.target) //<button>Submit</button>
//     console.log('a');
//     console.log(e.currentTarget)
//     console.log(e.eventPhase)
//   })
//   innerdiv.addEventListener('click', (e) => {
//     console.log('inner div clicked')
//     console.log(e.type) //click
//     console.log(e.target) //<button>Submit</button>
//     console.log('b');
//     console.log(e.currentTarget)
//     console.log(e.eventPhase)
//   })
//   submitButton.addEventListener('click', (e) => {
//     console.log('submit button clicked')
//     console.log(e.type) //click
//     console.log(e.target) //<button>Submit</button>
//     console.log('c');
//     console.log(e.currentTarget)
//     console.log(e.eventPhase)
//   })

// function doSomething() {
//     console.log('do Something');
// }

// submitButton.addEventListener('click', () => {
//     console.log('submit clicked');
// })
// submitButton.addEventListener('click', doSomething)

// submitButton.removeEventListener('click', doSomething)

// submitButton.removeEventListener('click',()=>{
//     console.log('submit clicked')
// })

const submitButton = document.getElementById('submit-btn-01') 
const inputElements = document.querySelectorAll('input')
  //   console.log(inputElements[0].value)
submitButton.addEventListener('click', (e) => {
  e.preventDefault()
  console.log('submit clicked')
 
  //   console.log(inputElements[1].value)
  const pElement = document.querySelector('p')
  if (
    inputElements[0].value.length === 0 ||
    inputElements[1].value.length === 0
  ) {
    pElement.textContent = 'some values are missing, please check'
  } else {
    pElement.textContent = 'Your input are complete'
  }
})

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM is loaded')
  })
  window.addEventListener('load', () => {
    console.log('Load')
  })
  window.addEventListener('beforeunload', () => {
    console.log('before unload')
    localStorage.setItem('myCat', 'Tom')
  })

inputElements[0].addEventListener('focus', () =>{
    console.log('on focus');
})
inputElements[0].addEventListener('blur', () =>{
    console.log('unfocus');
})