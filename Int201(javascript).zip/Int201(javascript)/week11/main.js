// //import esmodule
// import { sum } from './lib/util.js'

// // common js import
// //const { sum } = require('./lib/util.js')
// console.log(sum(1, 2));
// const rootNode = document

// console.log(rootNode);
// console.log(rootNode.nodeName);
// console.log(rootNode.nodeType);
// console.log(rootNode.nodeValue);

// console.log(document.documentElement);// root element=html
// console.log(document.documentElement.nodeType); // root 

// console.log(document.body);//html>body
// console.log(document.body.nodeType);

// console.log(document.head);//html>head



const headElement = document.head
console.log(headElement);

console.log(headElement.childNodes);//จะแสดงด่าทุก node
console.log(headElement.children);// จะแสดงค่าเฉพาะ elementและ html collection

const headChildNodes = headElement.childNodes
headChildNodes.forEach((hc) => {
    console.log(hc.nodeName);
    console.log(hc.nodeType);
    console.log(hc.nodeValue);
})
console.log('----------------------------------------------------------------');

const headChildren = headElement.children
Array.from(headChildren).forEach((hc) => {
    console.log(hc.nodeName);
    console.log(hc.nodeType);
    console.log(hc.nodeValue);
}) 

